<?php 

$pageTitle = "BOOKINGS";
include 'navbar.php';

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="assets/css/dashboard.css">
    <link rel="stylesheet" href="assets/css/hover.css">
</head>
<body>
    <div class="dashboard">
    </div>
  <div class="travelers">Travelers</div>
  <div class="hotels">Hotels</div>
  <div class="restaurants">Restaurants</div>


</body>
</html>





</body>
</html>